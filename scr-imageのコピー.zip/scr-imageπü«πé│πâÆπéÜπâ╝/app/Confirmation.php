<?php

require_once "../libs/init.php";
db_connect();

// 空文字、数字以外があるかチェック
EmptNumCheck();
