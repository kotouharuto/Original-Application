<?php
require_once "../libs/init.php";  
Logout();