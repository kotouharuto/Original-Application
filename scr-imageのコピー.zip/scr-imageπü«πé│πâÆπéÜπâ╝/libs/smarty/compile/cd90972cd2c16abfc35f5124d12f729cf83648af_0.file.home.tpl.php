<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-03 12:23:02
  from '/Applications/MAMP/htdocs/Original-Application/scr-image/libs/templates/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f50e026247540_73920532',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd90972cd2c16abfc35f5124d12f729cf83648af' => 
    array (
      0 => '/Applications/MAMP/htdocs/Original-Application/scr-image/libs/templates/home.tpl',
      1 => 1599135761,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f50e026247540_73920532 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .logoutlink {
            position: absolute;
            bottom: 100px;
        }
    </style>
</head>
<body>
    <a href="menupost.php" class="">メニューを追加する</a>
    <a href="logout.php" class="logoutlink">ログアウトする</a>
</body>
</html>

<?php }
}
