<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-29 23:43:26
  from '/Applications/MAMP/htdocs/Original-Application/scr-image/libs/templates/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f4ae81e77b360_27987772',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd435ba53f7e1f54681bfde0fe972b148242865da' => 
    array (
      0 => '/Applications/MAMP/htdocs/Original-Application/scr-image/libs/templates/home.tpl',
      1 => 1598744605,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f4ae81e77b360_27987772 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .logoutlink {
            position: absolute;
            bottom: 100px;
        }
    </style>
</head>
<body>
    <a href="logout.php" class="logoutlink">ログアウトする</a>
</body>
</html>

<?php }
}
