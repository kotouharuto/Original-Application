<?php
session_start();

$_SESSION['user_id'] = 222;
